﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class DeactivateMe : MonoBehaviour
{
    void Awake()
    {
        gameObject.SetActive(false);
    }
}