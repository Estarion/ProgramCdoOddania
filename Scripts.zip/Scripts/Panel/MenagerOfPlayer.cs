﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;

public class MenagerOfPlayer : MonoBehaviour {

    public Text textInformationAboutTurn;

    private static MenagerOfPlayer playerObject;
    private List<GameObject> listOfFields = new List<GameObject>();

    public List<GameObject> GetListOfFields()
    {
        return listOfFields;
    }

    public static MenagerOfPlayer Instance()
    {
        if (!playerObject)
        {
            playerObject = FindObjectOfType(typeof(MenagerOfPlayer)) as MenagerOfPlayer;
            if (!playerObject)
                Debug.LogError("There needs to be one active PlayerScript on a GameObject in your scene.");
        }

        return playerObject;
    }

    private void Awake()
    {
        //Adding game objects "field" to listOfFields to easy get gameObjects
        listOfFields.Add(GameObject.Find("Queluz"));
        listOfFields.Add(GameObject.Find("Coimbra"));
        listOfFields.Add(GameObject.Find("Funchal"));
        listOfFields.Add(GameObject.Find("Almada"));
        listOfFields.Add(GameObject.Find("Braga"));
        listOfFields.Add(GameObject.Find("Amadora"));
        listOfFields.Add(GameObject.Find("Vila Nova de Gaia"));
        listOfFields.Add(GameObject.Find("Porto"));
        listOfFields.Add(GameObject.Find("Lizbona"));

        // Add resources to all fields
        for (int i = 0; i < listOfFields.Count; i++)
        {
            StartGenerate(listOfFields[i], (i+1) * 100, (i+1) * 10);
        } 
    }

    private void Start()
    {
        PlayerSettings.SetTurn(1);
    }

    private void StartGenerate(GameObject gameObject, int _AmountOfGoldProducedInOneTurn, int _amountOfDiamondsProducedInOneTurn)
    {
        gameObject.GetComponent<FieldScript>().AmountOfGoldProducedInOneTurn = _AmountOfGoldProducedInOneTurn;
        gameObject.GetComponent<FieldScript>().AmountOfDiamondsProducedInOneTurn = _amountOfDiamondsProducedInOneTurn;
    }

    //This method generates all resources with new turn  
    public void NextTurn()
    {
        PlayerSettings.RiseTurn(1);
        textInformationAboutTurn.text = "TURA: " + PlayerSettings.GetTurn().ToString();
        for (int i = 0; i < listOfFields.Count; i++)
        {
            if (listOfFields[i].tag == "Your Field")
            {
                PlayerSettings.RiseDiamonds(listOfFields[i].GetComponent<FieldScript>().AmountOfDiamondsProducedInOneTurn);
                PlayerSettings.RiseGold(listOfFields[i].GetComponent<FieldScript>().AmountOfGoldProducedInOneTurn);
            }
        }
    }
}