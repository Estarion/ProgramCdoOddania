﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System.Collections.Generic;
using UnityEngine.Events;


public class LevelOfTheGameScript : MonoBehaviour {

    public int difficultyLevel;
    public int amountOfGold;
    public int amountOfDiamonds;
    public int turn;
    private Button myselfButton;

    private void Start()
    {
        // In the start give this button a Listener
        myselfButton = GetComponent<Button>();   
        myselfButton.onClick.AddListener(() => ChooseLevelOfTheGame(difficultyLevel, amountOfGold, amountOfDiamonds, turn));
    }

    private void ChooseLevelOfTheGame( int _difficultyLevel = 1, int _amountOfGold = 1000, int _amountOfDiamonds = 100, int _turn = 1)
    {
        PlayerSettings.SetDifficultyLevelOfTheGame(_difficultyLevel);
        PlayerSettings.SetGold(_amountOfGold);
        PlayerSettings.SetDiamonds(_amountOfDiamonds);
        PlayerSettings.SetTurn(_turn);
    }

    void Destroy()
    {
        myselfButton.onClick.RemoveListener(() => ChooseLevelOfTheGame(difficultyLevel, amountOfGold, amountOfDiamonds, turn));
    }
}
