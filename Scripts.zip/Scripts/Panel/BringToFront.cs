﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BringToFront : MonoBehaviour {

    private void OnEnable()
    {
        // Move the transform to the end of the local transform list. Then This element will be in front
        transform.SetAsLastSibling();
    }
}
