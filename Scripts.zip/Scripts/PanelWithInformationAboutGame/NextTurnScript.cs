﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
using UnityEngine.Events;

public class NextTurnScript : MonoBehaviour
{

    private MenagerOfPlayer menagerOfPlayer;

    private void Awake()
    {
        menagerOfPlayer = MenagerOfPlayer.Instance();
    }

    // This function change turn when player click a button with text "Następna tura"
    public void NextTurnButton()
    {
        menagerOfPlayer.NextTurn();
    }
}
