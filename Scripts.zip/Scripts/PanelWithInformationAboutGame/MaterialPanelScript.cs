﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;

public class MaterialPanelScript : MonoBehaviour {

    // This class display information about actual amount of Gold and Diamonds what the player have
    public Text text;
    private string nameOfMaterial = "";
    private int amount = -1;

    private void Start()
    {
        ChooseAndName();
    }

    private void Update()
    {
        Choose();
        text.text = nameOfMaterial + " : " + amount.ToString();
    }

    private void Choose()
    {
        switch (gameObject.name)
        {
            case "Material panel (Gold)":
                amount = PlayerSettings.GetGold();
                break;
            case "Material panel (Diamond)":
                amount = PlayerSettings.GetDiamonts();
                break;
        }
    }

    private void ChooseAndName()
    {
        switch (gameObject.name)
        {
            case "Material panel (Gold)":
                amount = PlayerSettings.GetGold();
                nameOfMaterial = "Gold";
                break;
            case "Material panel (Diamond)":
                amount = PlayerSettings.GetGold();
                nameOfMaterial = "Diamonds";
                break;
            default:
                Debug.LogError("The name  don't fit");
                PlayerSettings.SetGold(-1);
                PlayerSettings.SetDiamonds(-1);
                text.text = "Error";
                break;
        }
    }

}
