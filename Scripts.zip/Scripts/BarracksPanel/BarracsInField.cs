﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BarracsInField : MonoBehaviour {
    
    private ScrollCardsList scrollCardsList = new ScrollCardsList();
    public List<CharacterClass> listInThisContainer;
    public int levelOfUpgrade = 0;
    public GameObject prefabOfTheCardPanel;
    public GameObject player;
    
    private void Awake()
    {
        scrollCardsList.player = player;
        levelOfUpgrade = levelOfUpgrade + PlayerSettings.GetDifficultyLevelOfTheGame();
        scrollCardsList.CreateCards(this.GetComponent<Transform>(), listInThisContainer, prefabOfTheCardPanel, levelOfUpgrade, scrollCardsList);
    }
}
