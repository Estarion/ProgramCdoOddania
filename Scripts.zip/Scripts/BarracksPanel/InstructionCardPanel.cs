﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;

public class InstructionCardPanel : MonoBehaviour {

    public GameObject instructionCardPanelObject;

    private static InstructionCardPanel instructionCardPanel;

    public static InstructionCardPanel Instance()
    {
        if (!instructionCardPanel)
        {
            instructionCardPanel = FindObjectOfType(typeof(InstructionCardPanel)) as InstructionCardPanel;
            if (!instructionCardPanel)
                Debug.LogError("There needs to be one active InstructionCardPanel script on a GameObject in your scene.");
        }

        return instructionCardPanel;
    }

    public void OpenInstructionCardsPanel()
    {
        instructionCardPanelObject.SetActive(true);
    }

    public void CancelInstructionCardsPanel()
    {
        instructionCardPanelObject.SetActive(false);
    }
}
