﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System.Collections.Generic;

public class UpgradeBarracksButton : MonoBehaviour {

    // These are veriables added in unity
    public ScrollCardsList barracksScrollCardsList;
    public ScrollCardsList partyScrollCardsList;
    public Text umprageText;

    private List<Image> listOfStars = new List<Image>();
    public Image star1;
    public Image star2;
    public Image star3;
    public Image star4;

    private int levelOfUpgrade = 0;

    private Color colorOfImageWhenUpgrade = new Color(1, 1, 1, 1);

    private void Awake()
    {
        listOfStars.Add(star1);
        listOfStars.Add(star2);
        listOfStars.Add(star3);
        listOfStars.Add(star4);
    }
    // This function upgrade level of the barrack when player click a button with text "Ulepsz"
    public void UpgradePanel()
    {
        if(PlayerSettings.GetGold() >=2000 && levelOfUpgrade < listOfStars.Count)
        {
            PlayerSettings.RiseGold(-2000);
            umprageText.text = "Oczywiście";
            levelOfUpgrade++;
            listOfStars[levelOfUpgrade - 1].color = colorOfImageWhenUpgrade;
            UpgradeScrollCardsList();
        }
        else if (PlayerSettings.GetGold() <2000)
        {
            umprageText.text = "Masz za mało złota";
        }
        else
        {
            umprageText.text = "Masz maksymalny poziom ulepszenia koszar";
        }
    }

    private void UpgradeScrollCardsList()
    {
        barracksScrollCardsList.SetLevelOfUpgrade(levelOfUpgrade);
        partyScrollCardsList.SetLevelOfUpgrade(levelOfUpgrade);
    }
}
