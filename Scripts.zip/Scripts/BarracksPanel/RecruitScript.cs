﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System.Collections.Generic;

public class RecruitScript : MonoBehaviour {

    public ScrollCardsList barracksScrollCardsList;
    public CharacterClass characterClass;
    List<string> listOfClass = new List<string>();

    private void Awake()
    {
        listOfClass.Add("Warrior");
        listOfClass.Add("Mage");
        listOfClass.Add("Archer");
    }

    // This function add a random characterClass to barracksScrollCardsList when player click button with text "Rekrutuj"
    public void AddRecruit()
    {
        characterClass.nameOfClass = listOfClass[(int)Random.Range(0, listOfClass.Count)];
        barracksScrollCardsList.AddRecruit(characterClass);
    }
}
