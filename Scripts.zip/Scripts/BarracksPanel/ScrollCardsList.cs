﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System.Collections.Generic;

[System.Serializable]
public class CharacterClass
{
    public string nameOfClass;    // To create cards by giving to List<CharacterClass> listInThisContainer this 
    public string index;          // To find element what is connected by name with concrete card, in List<characterClass> 
    public int level;             // Level od the card
}

public class ScrollCardsList : MonoBehaviour
{
    public List<CharacterClass> listInThisContainer;
    public Transform contentPanel;
    public ScrollCardsList otherContainer;
    public GameObject prefabOfTheCardPanel;
    public GameObject player;
    public Text displayLayaut;

    private int levelOfUpgrade = 0;

    public void SetLevelOfUpgrade(int _levelOfUpgrade)
    {
        levelOfUpgrade = _levelOfUpgrade;
    }

    public int GetLevelOfTheUpgrade()
    {
        return levelOfUpgrade;
    }

    // Use this for initialization
    private void Awake()
    {
        CreateCards(contentPanel, listInThisContainer, prefabOfTheCardPanel, levelOfUpgrade, this);
    }

    public void CreateCards(Transform _contentPanel, List<CharacterClass> _listInThisContainer, 
        GameObject _prefabOfTheCardPanel, int _levelOfUmprage, ScrollCardsList _thisScrollCardList)
    {
        // In the start of the game _contentPanel.childCount == 0 that mean we create a new card for every
        // CharacterClass in _listInThisContainer but when we add a new card by AddRecruit() in running game
        // _contentPanel.childCount != 0 but a number of cards after execute this function in below
        // that mean we can put and create a new Card without act an another cards
        // For all children in this do:
        for (int i = _contentPanel.childCount; i < _listInThisContainer.Count; i++)
        {
            // Create a copy of _prefabOfTheCardPanel and add this copy new parameters
            GameObject newCardPanel = GetObject(_prefabOfTheCardPanel);
            // Set  parent to this
            newCardPanel.transform.SetParent(_contentPanel);
            // Change parameters in script of the new object (newCardPanel)
            CardPanel cardPanel = newCardPanel.GetComponent<CardPanel>();
            cardPanel.Setup(_listInThisContainer[i], _thisScrollCardList, _levelOfUmprage);
            // when we create a new obejct, this object new parent is Assets but we want to put this
            // new object to panel where is in Cavas with local Scale != (1,1,1), that is why we
            // must sent new localScale
            newCardPanel.GetComponent<RectTransform>().localScale = new Vector3(1,1,1);
        }
    }

   private GameObject GetObject(GameObject prefab)
    {
        GameObject spawnedGameObject;

        spawnedGameObject = (GameObject)GameObject.Instantiate(prefab);

        // put the instance in the root of the scene and enable it
        spawnedGameObject.transform.SetParent(null);
        spawnedGameObject.SetActive(true);

        // return a reference to the instance
        return spawnedGameObject;
    }

    public void TryTransferItemToOtherShop(CharacterClass characterClass, string nameIndex)
    {
        GameObject cardPanel = GameObject.Find(nameIndex);
        SlowDownTheSystem();
        if((otherContainer.name == "ContentParty" && otherContainer.GetComponent<Transform>().childCount < 4) || otherContainer.name == "ContentBarracks")
        {
            AddItem(cardPanel, this, otherContainer, characterClass);
            cardPanel.GetComponent<CardPanel>().SetScrollCardslist(otherContainer);
        }
    }

    void AddItem(GameObject item, ScrollCardsList thisContainer, ScrollCardsList otherContainer, CharacterClass characterClass)
    {
        // Remove received characterClass from this this List<CharacterClass> and and received characterClass to another List<CharacterList>
        otherContainer.listInThisContainer.Add(characterClass);
        item.transform.SetParent(null);
        item.transform.SetParent(otherContainer.GetComponent<Transform>());
        for (int i = thisContainer.listInThisContainer.Count - 1; i >= 0; i--)
        {
            if (thisContainer.listInThisContainer[i].index == characterClass.index)
            {
                thisContainer.listInThisContainer.RemoveAt(i);
            }
        }
    }

    public void AddRecruit(CharacterClass newRecruit)
    {
        // If player have enough gold then create a random class => card and add it to Barracks
        if (PlayerSettings.GetGold() >= 500)
        {
            PlayerSettings.RiseGold(-500);
            listInThisContainer.Add(newRecruit);
            displayLayaut.text = "Oczywiście";
            CreateCards(contentPanel, listInThisContainer, prefabOfTheCardPanel, levelOfUpgrade, this);
        }
        else
        {
            displayLayaut.text = "Nie masz  wystarczającej ilości złota";
        }
    }
    // This function slow down our system to change parameters in our class
    IEnumerator SlowDownTheSystem()
    {
        Debug.Log("nie wiem czy to usunoc");
        Time.timeScale = 2.0F;
        yield return new WaitForSeconds(111111111.0f);
    }
}