﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;

public class BarracksPanel : MonoBehaviour {

    private static BarracksPanel baracksPanel;

    public Button closeButton1;
    public Button closeButton2;

    public GameObject barracksPanelObject;

    public static BarracksPanel Instance()
    {
        if (!baracksPanel)
        {
            baracksPanel = FindObjectOfType(typeof(BarracksPanel)) as BarracksPanel;
            if (!baracksPanel)
                Debug.LogError("There needs to be one active BarackPanel script on a GameObject in your scene.");
        }
        return baracksPanel;
    }

    public void ActiveEvents()
    {
        barracksPanelObject.SetActive(true);

        closeButton1.gameObject.SetActive(false);
        closeButton2.gameObject.SetActive(false);

        closeButton1.onClick.RemoveAllListeners();
        closeButton1.onClick.AddListener(ClosePanel);
        closeButton1.gameObject.SetActive(true);
        
        closeButton2.onClick.RemoveAllListeners();
        closeButton2.onClick.AddListener(ClosePanel);
        closeButton2.gameObject.SetActive(true);
    }
    void ClosePanel()
    {
        barracksPanelObject.SetActive(false);
    }
}
