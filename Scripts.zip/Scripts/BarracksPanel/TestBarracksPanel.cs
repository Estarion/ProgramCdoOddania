﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestBarracksPanel : MonoBehaviour {

    private BarracksPanel barackPanel;

    void Awake()
    {
        barackPanel = BarracksPanel.Instance();
    }

    public void BarracksWindow()
    {
        barackPanel.ActiveEvents();
    }
}
