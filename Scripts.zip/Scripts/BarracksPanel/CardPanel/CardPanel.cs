﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System.Collections.Generic;
using UnityEngine.EventSystems;

public class CardPanel :MonoBehaviour, IPointerClickHandler
{
    // These are veriables added in unity. 
    public Text textName;
    public Text textPower;
    public Text textMagicPower;
    public Text textArmour;
    public Text textHealthPoints;
    public Text textChanceToCriticalAttack;
    public Text textLevel;
    public Text textRarity;
    public Image imageOfCharacter;
    public Image imageOfAttribute;
    public Button buttonToUmprage;
    public CardPanel cardPanel;

    // These are variables in C#
    private InstructionCardPanel instructionCardPanel;
    private CharacterClass characterClass;
    private ScrollCardsList scrollCardsList;

    public ScrollCardsList GetScrollCardsList()
    {
        return scrollCardsList;
    }

    public void SetScrollCardslist(ScrollCardsList _scrollCardslist)
    {
        scrollCardsList = _scrollCardslist;
    }

    public CharacterClass GetCharacterClass()
    {
        return characterClass;
    }

    public void SetCharacterClass(CharacterClass _charcterClass)
    {
        characterClass = _charcterClass;
    }

    // Sprites for mage
    public Sprite imageOfMageCharacter;
    public Sprite imageOfMageAttribute;

    // Sprites for warrior
    public Sprite imageOfWarriorCharacter;
    public Sprite imageOfWarriorAttribute;

    // Sprites for archer
    public Sprite imageOfArcherCharacter;
    public Sprite imageOfArecherAttribute;

    Warrior warrior = new Warrior();
    Mage mage = new Mage();
    Archer archer = new Archer();

    //Use this for initialization
    private void Awake()
    {
        instructionCardPanel = InstructionCardPanel.Instance();
    }

    public void Setup(CharacterClass currentCharacterclass, ScrollCardsList currentScrollCardsList, int levelOfTheUpgrade)
    {
        // LevelOfTheUpgrade is a level of the upgrade in barracks and this level mean a possibility for powerful subclass. 
        // Below are parameters to identify and link this card object in ScrollCardsList with List<CharacterClass>
        this.name = Random.Range(1, 1000000000).ToString();
        characterClass = currentCharacterclass;
        characterClass.index = this.name;
        scrollCardsList = currentScrollCardsList;
        switch (characterClass.nameOfClass)
        {
            case "Mage":
                // This function slow down our system to change parameters in our class
                SlowDownTheSystem(); 
                Debug.Log("nie wiem czy to poprawić, sprawdź pod  koniec");
                mage.ChangerParamets(0);
                mage.ChangerParamets(levelOfTheUpgrade);
                // Give this card parameters from class Mage, this class Mage isn't linked to our card.
                mage.Setup(textName, textHealthPoints, textPower, textMagicPower, textArmour, textChanceToCriticalAttack, textLevel, textRarity);
                for(int i=1; i< characterClass.level; i++)
                {
                    // If we in the unity set a different level (!=1) for the card then this code in below upgrade level on this card.
                    buttonToUmprage.GetComponent<UpgradeLevelButton>().UpgradeLevelOfThisCard(this);
                }
                // Color signalize rarity of this card
                ChangeColorWhenCardChangeRarity(this);
                imageOfCharacter.sprite = imageOfMageCharacter;  
                imageOfAttribute.sprite = imageOfMageAttribute;
                break;
            case "Warrior":
                SlowDownTheSystem();
                warrior.ChangerParamets(0);
                warrior.ChangerParamets(levelOfTheUpgrade);
                warrior.Setup(textName, textHealthPoints, textPower, textMagicPower, textArmour, textChanceToCriticalAttack, textLevel, textRarity);
                ChangeColorWhenCardChangeRarity(this);
                for (int i = 1; i < characterClass.level; i++)
                {
                    // If we in the unity set a different level (!=1) for the card then this code in below upgrade level on this card.
                    buttonToUmprage.GetComponent<UpgradeLevelButton>().UpgradeLevelOfThisCard(this);
                }
                // Color signalize rarity of this card
                imageOfCharacter.sprite = imageOfWarriorCharacter; 
                imageOfAttribute.sprite = imageOfWarriorAttribute;
                break;
            case "Archer":
                SlowDownTheSystem();
                archer.ChangerParamets(0);
                archer.ChangerParamets(levelOfTheUpgrade);
                archer.Setup(textName, textHealthPoints, textPower, textMagicPower, textArmour, textChanceToCriticalAttack, textLevel, textRarity);
                ChangeColorWhenCardChangeRarity(this);
                for (int i = 1; i < characterClass.level; i++)
                {
                    // If we in the unity set a different level (!=1) for the card then this code in below upgrade level on this card.
                    buttonToUmprage.GetComponent<UpgradeLevelButton>().UpgradeLevelOfThisCard(this);
                }
                // Color signalize rarity of this card
                imageOfCharacter.sprite = imageOfArcherCharacter; 
                imageOfAttribute.sprite = imageOfArecherAttribute;
                break;
            default:
                Debug.LogError("characterClass.nameOfClass have a error");
                break;
        }
    }

    // This function slow down our system to change parameters in our class
    IEnumerator SlowDownTheSystem()
    {
        Time.timeScale = 1.0F;
        yield return new WaitForSeconds(111111111.0f);
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        // If we click in this object with left button then
        if (eventData.button == PointerEventData.InputButton.Left)
        {
            scrollCardsList.TryTransferItemToOtherShop(characterClass, this.name);
        }
        // ...  if right button then
        else if (eventData.button == PointerEventData.InputButton.Right)
        {
            instructionCardPanel.OpenInstructionCardsPanel();
        }
    }

    public void ChangeColorWhenCardChangeRarity(CardPanel cardPanel)
    {
        switch (cardPanel.textRarity.text)
        {
            case "0":
                cardPanel.GetComponent<Image>().color = Color.white;
                break;
            case "1":
                cardPanel.GetComponent<Image>().color = new Color(0.282352941f, 0.725490196f, 0.764705882f, 1);
                break;
            case "2":
                cardPanel.GetComponent<Image>().color = new Color(0.549019607f, 0.32941176f, 0.7215686274f);
                break;
            case "3":
                cardPanel.GetComponent<Image>().color = new Color(1, 0.74509803921f, 0, 1);
                break;
            case "4":
                cardPanel.GetComponent<Image>().color = new Color(1, 0.6f, 0, 1);
                break;
        }
    }
}




