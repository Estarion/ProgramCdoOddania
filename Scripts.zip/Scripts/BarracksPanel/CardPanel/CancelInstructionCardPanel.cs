﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;

public class CancelInstructionCardPanel : MonoBehaviour {

    InstructionCardPanel instructionCardPanel;

    private void Awake()
    {
        instructionCardPanel = InstructionCardPanel.Instance();
    }

    public void CancelInstructionCardsPanel()
    {
        instructionCardPanel.CancelInstructionCardsPanel();
    }
}
