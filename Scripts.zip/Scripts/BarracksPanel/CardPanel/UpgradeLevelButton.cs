﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System.Collections.Generic;
using UnityEngine.EventSystems;
using System;

public class UpgradeLevelButton : MonoBehaviour {

    public CardPanel cardPanel;
    public Sprite spriteOfIconWhenYourCardHaveMaxLevel;
    private int umprageCost = 30;
    private int multiplierOfCost = 4;

    // This function upgrade level of the card when player click a button in the bottom of the card
    public void UpgradeLevelOfThisCard(CardPanel cardPanel)
    {
        //Take a ScrollCardList from player to get list of fields
        GameObject player = cardPanel.GetScrollCardsList().player;
        // Card's level is divide to  two parts.  One part (0,4) and second part(5,5)
        if ((Int32.Parse(cardPanel.textLevel.text) < 4) && (PlayerSettings.GetDiamonts() >= umprageCost))
        {
            // If this game starts take diamonds from player every time when you upgrade level of the card
            if(PlayerSettings.GetTurn() > 0) PlayerSettings.RiseDiamonds(-umprageCost);
            // And dependence of level give this card better stats
            switch (cardPanel.textLevel.text)
            {
                case "1":
                    switch (cardPanel.GetCharacterClass().nameOfClass)
                    {
                        case "Mage":
                            SetupWhenLeveled(0, 1, 0, 1, 0);
                            break;
                        case "Warrior":
                            SetupWhenLeveled(1, 0, 0, 2, 5);
                            break;
                        case "Archer":
                            SetupWhenLeveled(2, 0, 0, 0, 10);
                            break;
                    }
                    break;
                case "2":
                    switch (cardPanel.GetCharacterClass().nameOfClass)
                    {
                        case "Mage":
                            SetupWhenLeveled(0, 1, 0, 1, 0);
                            break;
                        case "Warrior":
                            SetupWhenLeveled(1, 0, 1, 1, 0);
                            break;
                        case "Archer":
                            SetupWhenLeveled(1, 0, 0, 1, 10);
                            break;
                    }
                    break;
                case "3":
                    switch (cardPanel.GetCharacterClass().nameOfClass)
                    {
                        case "Mage":
                            SetupWhenLeveled(0, 2, 0, 1, 0);
                            break;
                        case "Warrior":
                            SetupWhenLeveled(2, 0, 1, 0, 0);
                            break;
                        case "Archer":
                            SetupWhenLeveled(1, 0, 0, 2, 20);
                            break;
                    }
                    break;
                default:
                    break;
            }
        }
        else if ((Int32.Parse(cardPanel.textLevel.text) == 4) && (PlayerSettings.GetDiamonts() >= umprageCost*multiplierOfCost))
        {
            if (PlayerSettings.GetTurn()>0) PlayerSettings.RiseDiamonds(-umprageCost*multiplierOfCost);
            switch (cardPanel.GetCharacterClass().nameOfClass)
            {
                case "Mage":
                    //  if later we upgrade a card then better stats this card get
                    if (PlayerSettings.GetTurn() >= 40)
                        SetupWhenLeveled(0, 3, 0, 4, 0);
                    else if (PlayerSettings.GetTurn() >= 30)
                        SetupWhenLeveled(0, 2, 0, 3, 0);
                    else if (PlayerSettings.GetTurn() >= 20)
                        SetupWhenLeveled(0, 2, 0, 2, 0);
                    else if (PlayerSettings.GetTurn() >= 10)
                        SetupWhenLeveled(0, 2, 0, 1, 0);
                    else SetupWhenLeveled(0, 1, 0, 1, 0);
                    break;
                case "Warrior":
                    if (PlayerSettings.GetTurn() >= 40)
                        SetupWhenLeveled(2, 0, 2, 1, 0);
                    else if (PlayerSettings.GetTurn() >= 30)
                        SetupWhenLeveled(1, 0, 2, 1, 0);
                    else if (PlayerSettings.GetTurn() >= 20)
                        SetupWhenLeveled(2, 0, 1, 3, 0);
                    else if (PlayerSettings.GetTurn() >= 10)
                        SetupWhenLeveled(1, 0, 1, 2, 0);
                    else SetupWhenLeveled(0, 0, 1, 1, 0);
                    break;
                case "Archer":
                    if (PlayerSettings.GetTurn() >= 40)
                        SetupWhenLeveled(2, 0, 0, 1, 40);
                    else if (PlayerSettings.GetTurn() >= 30)
                        SetupWhenLeveled(2, 0, 0, 1, 20);
                    else if (PlayerSettings.GetTurn() >= 20)
                        SetupWhenLeveled(2, 0, 0, 1, 10);
                    else if (PlayerSettings.GetTurn() >= 10)
                        SetupWhenLeveled(1, 0, 0, 1, 20);
                    else SetupWhenLeveled(1, 0, 0, 1, 10); ;
                    break;
            }
            cardPanel.transform.Find("Level").GetComponent<Image>().sprite = spriteOfIconWhenYourCardHaveMaxLevel;
            cardPanel.transform.Find("Level").GetComponent<RectTransform>().localScale = new Vector3(2, 2, 1);
            cardPanel.transform.Find("Level").GetComponent<RectTransform>().localPosition = new Vector3(182.4f, 265.19f, 0);
            cardPanel.textRarity.text = (1 + Int32.Parse(cardPanel.textRarity.text)).ToString();
            cardPanel.ChangeColorWhenCardChangeRarity(cardPanel);
        }

    }

    // Replace current card stats with better
    void SetupWhenLeveled(int plusPower, int plusMagicPower, int plusArmour, int plusHealthPoints, int plusChanceToCriticalAttack)
    {
        cardPanel.textPower.text = (plusPower + Int32.Parse(cardPanel.textPower.text)).ToString();
        cardPanel.textMagicPower.text = (plusMagicPower + Int32.Parse(cardPanel.textMagicPower.text)).ToString();
        cardPanel.textArmour.text = (plusArmour + Int32.Parse(cardPanel.textArmour.text)).ToString();
        cardPanel.textHealthPoints.text = (plusHealthPoints + Int32.Parse(cardPanel.textHealthPoints.text)).ToString();
        cardPanel.textChanceToCriticalAttack.text = (plusChanceToCriticalAttack + Int32.Parse(cardPanel.textChanceToCriticalAttack.text)).ToString();
        cardPanel.textLevel.text = (1 + Int32.Parse(cardPanel.textLevel.text)).ToString();
    }
}
