﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;

public class TestModalPanel : MonoBehaviour
{
    // These are veriables added in unity 
    public GameObject field;
    public Sprite iconForPanel;
    public Sprite yesIcon;
    public Sprite noIcon;
    public Sprite cancelIcon;

    private MenagerOfPlayer menagerOfPlayer;
    private ModalPanel modalPanel;
    private FightPanel fightPanel;

    void Awake()
    {
        fightPanel = FightPanel.Instance();
        modalPanel = ModalPanel.Instance();
        menagerOfPlayer = MenagerOfPlayer.Instance();
    }

    //  Send to the Modal Panel to set up the Buttons and functions to call
    public void ModalWindowYNCI()
    {
        ModalPanelDetails modalPanelDetails = new ModalPanelDetails()
        {
            title = field.name
        };

        // If we send to the Modal Panel to set up the Buttons and functions to call from gameObject "field"
        // with tag "Enemy Field" then we get different text in modalPanelDetails.information than field have tag "Your Field"
        // That mean the player can attack this fields always but don't get additional resources
        if (field.tag == "Enemy Field")
        {
            modalPanelDetails.information =
                "To pole należy do " + field.name + ".\nJeśli nie chcesz zginąć to zawróć." +
                WriteOutInformation() +
                "\n\nCzy jesteś wystarczająco odważny by zaatakować ?\nA  może stchórzysz ?" +
                "Bycie tchórzem to nic wstydliwego";
        }
        else
        {
            modalPanelDetails.information =
                "To pole należy do " + field.name + ". Już posiadasz to pole.\nZawróć!!!" +
                WriteOutInformation() +
                "\n\nZniszczyłeś już już wystarczająco wiosek.  Odejdź !!!";
        }
        modalPanelDetails.agreementText = "Czy chcesz walczyć ?";
        modalPanelDetails.iconImage = iconForPanel;

        modalPanelDetails.yesButtonDetails = new EventButtonDetails()
        {
            buttonTitle = "Yes",
            icon = yesIcon,
            action = YesFunction
        };
        
        modalPanelDetails.noButtonDetails = new EventButtonDetails()
        {
            buttonTitle = "No",
            icon = noIcon,
            action = NoFunction
        };
        
        modalPanelDetails.cancelButtonDetails = new EventButtonDetails()
        {
            buttonTitle = "Close",
            icon = cancelIcon,
            action = CancelFunction,
        };

        modalPanel.Choice(modalPanelDetails);
    }

    private string WriteOutInformation()
    {
        string textToDisplay = "\nTo pole generuje:" + "\nIlość złota: " + (field.GetComponent<FieldScript>().AmountOfGoldProducedInOneTurn).ToString() +
                "\nIlość diamentów: " + (field.GetComponent<FieldScript>().AmountOfDiamondsProducedInOneTurn).ToString();
        return textToDisplay;
    }

    //  The function to call when the button is clicked
    void YesFunction()
    {
        fightPanel.StartFight(field);
        modalPanel.gameObject.SetActive(false);
        menagerOfPlayer.NextTurn();
        PlayerSettings.RiseTurn(1);
    }

    void NoFunction()
    {
        // I don't have idea but can be used next time
    }

    void CancelFunction()
    {
        // I don't have idea but can be used next time
    }
}