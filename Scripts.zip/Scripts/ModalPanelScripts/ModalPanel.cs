﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;

public class EventButtonDetails
{
    public string buttonTitle;
    public Sprite icon;
    public UnityAction action;
}


public class ModalPanelDetails
{
    public string title; 
    public string information;
    public string agreementText;
    public Sprite iconImage;
    public EventButtonDetails yesButtonDetails;
    public EventButtonDetails noButtonDetails;
    public EventButtonDetails cancelButtonDetails;
}


public class ModalPanel : MonoBehaviour
{
    public Text title;
    public Text information;
    public Text agreementText;
    public Image iconImage;
    public Button yesButton;
    public Button noButton;
    public Button closeButton;

    public GameObject modalPanelObject;

    private static ModalPanel modalPanel;

    public static ModalPanel Instance()
    {
        if (!modalPanel)
        {
            modalPanel = FindObjectOfType(typeof(ModalPanel)) as ModalPanel;
            if (!modalPanel)
                Debug.LogError("There needs to be one active ModalPanel script on a GameObject in your scene.");
        }

        return modalPanel;
    }

    public void Choice(ModalPanelDetails details)
    {
        modalPanelObject.SetActive(true);

        // First, setActive all to false, if we want use this elements then we must put this information in 
        // (ModalPanelDetails details). If details don't have adequate information then they still will be inactive.
        // In that way we can create a one Object what can do nearly everything.
        this.iconImage.gameObject.SetActive(false);
        yesButton.gameObject.SetActive(false);
        noButton.gameObject.SetActive(false);
        closeButton.gameObject.SetActive(false);

        this.title.text = details.title;
        this.information.text = details.information;
        this.agreementText.text = details.agreementText;

        if (details.iconImage)
        {
            this.iconImage.sprite = details.iconImage;
            this.iconImage.gameObject.SetActive(true);
        }

        yesButton.onClick.RemoveAllListeners();
        yesButton.onClick.AddListener(details.yesButtonDetails.action);
        yesButton.onClick.AddListener(ClosePanel);
        yesButton.gameObject.SetActive(true);

        if (details.noButtonDetails != null)
        {
            noButton.onClick.RemoveAllListeners();
            noButton.onClick.AddListener(details.noButtonDetails.action);
            noButton.onClick.AddListener(ClosePanel);
            noButton.gameObject.SetActive(true);
        }

        if (details.cancelButtonDetails != null)
        {
            closeButton.onClick.RemoveAllListeners();
            closeButton.onClick.AddListener(details.cancelButtonDetails.action);
            closeButton.onClick.AddListener(ClosePanel);
            closeButton.gameObject.SetActive(true);
        }
    }

    void ClosePanel()
    {
        modalPanelObject.SetActive(false);
    }
}