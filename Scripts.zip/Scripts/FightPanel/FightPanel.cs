﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;
using System;

[System.Serializable]
public class ParametsOfCard
{
    public int health;
    public int power;
    public int magicPower;
    public int armour;
    public int chanceToDoubleAttack; 

    public ParametsOfCard(CardPanel _cardPanel)
    {
        health = Int32.Parse(_cardPanel.textHealthPoints.text);
        power = Int32.Parse(_cardPanel.textPower.text);
        magicPower = Int32.Parse(_cardPanel.textMagicPower.text);
        armour = Int32.Parse(_cardPanel.textArmour.text);
        chanceToDoubleAttack = Int32.Parse(_cardPanel.textChanceToCriticalAttack.text);
    }
}
public class FightPanel : MonoBehaviour {

    //------------------------------------------------------------------------------------------------------------
    // this gameObjects are place/section where program create a prefab of the cards
    public GameObject enemyPlaceForCardNumber1;
    public GameObject enemyPlaceForCardNumber2;
    public GameObject enemyPlaceForCardNumber3;
    public GameObject enemyPlaceForCardNumber4;

    public GameObject playerPlaceForCardNumber1;
    public GameObject playerPlaceForCardNumber2;
    public GameObject playerPlaceForCardNumber3;
    public GameObject playerPlaceForCardNumber4;

    public Button buttonToClosePanel;

    private List<GameObject> listOfPlayerFieldsOfCards = new List<GameObject>();
    private List<GameObject> listOfEnemyFieldsOfCards = new List<GameObject>();

    public GameObject partyPanel;

    //---------------------------------------------------------------------------------------------------------------

    public GameObject fightPanelObject;

    private static FightPanel fightPanel;

    public static FightPanel Instance()
    {   
        if (!fightPanel)
        {
            fightPanel = FindObjectOfType(typeof(FightPanel)) as FightPanel;
            if (!fightPanel)
                Debug.LogError("There needs to be one active FightPanel script on a GameObject in your scene.");
        }
        return fightPanel;
    }

    public void OpenFightPanel()
    {
        fightPanelObject.SetActive(true);
    }

    public void CloseFightPanel()
    {
        fightPanelObject.SetActive(false);
    }

    //----------------------------------------------------------------------------------------------------------------------------
    //  Script for game system 

    private void Awake()
    {
        listOfEnemyFieldsOfCards.Add(enemyPlaceForCardNumber1);
        listOfEnemyFieldsOfCards.Add(enemyPlaceForCardNumber2);
        listOfEnemyFieldsOfCards.Add(enemyPlaceForCardNumber3);
        listOfEnemyFieldsOfCards.Add(enemyPlaceForCardNumber4);

        listOfPlayerFieldsOfCards.Add(playerPlaceForCardNumber1);
        listOfPlayerFieldsOfCards.Add(playerPlaceForCardNumber2);
        listOfPlayerFieldsOfCards.Add(playerPlaceForCardNumber3);
        listOfPlayerFieldsOfCards.Add(playerPlaceForCardNumber4);

        buttonToClosePanel.onClick.AddListener(ButtonListenerToCloseFightPanel);
    }

    public void ButtonListenerToCloseFightPanel()
    {
        DestroyCardsInsidePanel();
        CloseFightPanel();
    }

    void DestroyCardsInsidePanel()
    {
        //  when we ended fight then we want destroy a prefabs in lists because we want use this script/FightPanel once again 
        for (int i = 0; i < 4; i++)
        {
            if (listOfEnemyFieldsOfCards[i].transform.childCount == 1)
            {
                Destroy(listOfEnemyFieldsOfCards[i].transform.GetChild(0).gameObject);
            }
            if (listOfPlayerFieldsOfCards[i].transform.childCount == 1)
            {
                Destroy(listOfPlayerFieldsOfCards[i].transform.GetChild(0).gameObject);
            }
        }
    }

    private void GetTheCards(GameObject field)
    {
        //  This method is a door for this Script. Put prefabs of cards from given field and PartyPanel and prepare to Fight()
        DestroyCardsInsidePanel();
        for (int i = 0; i< partyPanel.transform.childCount;i++)
        {
            ChangeSettingsOfCard(i, listOfPlayerFieldsOfCards, this.partyPanel.transform.GetChild(i).gameObject);
        }
        for (int i = 0,  j = 1; i < field.transform.GetChild(0).gameObject.transform.childCount; i++)
        {
            // In battle field can be only 4 pairs, no more
            if (i >= 4)
            {
                //  For that reason if programer put and create more than 4 
                Destroy(field.transform.GetChild(0).transform.GetChild(field.transform.GetChild(0).gameObject.transform.childCount-j).gameObject);
                j++;
            }
            ChangeSettingsOfCard(i, listOfEnemyFieldsOfCards, field.transform.GetChild(0).transform.GetChild(i).gameObject);
        }
    }

    private void ChangeSettingsOfCard(int indexforGameObject, List<GameObject> listOfGameObjects, GameObject prefab)
    {
        // Creata a new gameObject (a copy of  prefab) and set parent (List<GameObject> listOfGameObjects) for this new object
        GameObject spawnedGameObject;
        spawnedGameObject = (GameObject)GameObject.Instantiate(prefab);
        spawnedGameObject.SetActive(true);
        spawnedGameObject.transform.SetParent(listOfGameObjects[indexforGameObject].transform, true);
        spawnedGameObject.GetComponent<RectTransform>().localScale = new Vector3(0.6f, 0.551f, 1);
        spawnedGameObject.GetComponent<RectTransform>().anchorMin = new Vector2(0.5f, 0.5f);
        spawnedGameObject.GetComponent<RectTransform>().anchorMax = new Vector2(0.5f, 0.5f);
        spawnedGameObject.GetComponent<RectTransform>().pivot = new Vector2(0.5f, 0.5f);
        spawnedGameObject.GetComponent<RectTransform>().localPosition = new Vector3(0, 0, 0);
    }

    private void Fight(FieldScript field)
    {
        // If (numberOfPlayerPoints > numberOfEnemyPoints) then player win
        int numberOfEnemyPoints = 0;    
        int numberOfPlayerPoints = 0;

        // this set of colors are  for player to see what card win/lose/draw
        Color colorForDraw = new Color(0.756862745f, 0.756862745f, 0.756862745f, 0.894117647f);
        Color colorForVictory = new Color(0.345098039f, 0.4862745098f, 1, 0.894117647f);
        Color colorForLose = new Color(1, 0.2588235f, 0.2588235f, 0.894117647f);

        for (int i = 0; i<4;i++ )
        {
            int pointForPlayer = 0;
            int pointForEnemy = 0;

            //  If enemy don't have card in section listOfEnemyFieldsOfCards[i]
            if (listOfEnemyFieldsOfCards[i].transform.childCount == 0) pointForPlayer = 1;
            //  If player don't have card in section listOfPlayerFieldsOfCards[i]
            if (listOfPlayerFieldsOfCards[i].transform.childCount == 0) pointForEnemy = 1;
            if ((pointForPlayer == 1) && (pointForEnemy == 1)) // If player and enemy don't have cards in its section
            {
                listOfPlayerFieldsOfCards[i].gameObject.GetComponent<Image>().color = colorForDraw;
                listOfEnemyFieldsOfCards[i].gameObject.GetComponent<Image>().color = colorForDraw;
            }
            else if (pointForPlayer > pointForEnemy)        //  If enemy don't have card in section listOfEnemyFieldsOfCards[i]
            {
                numberOfPlayerPoints++;
                listOfPlayerFieldsOfCards[i].gameObject.GetComponent<Image>().color = colorForVictory;
                listOfEnemyFieldsOfCards[i].gameObject.GetComponent<Image>().color = colorForLose;
            }
            else if( pointForPlayer < pointForEnemy)        //  If player don't have card in section listOfPlayerFieldsOfCards[i]
            {
                numberOfEnemyPoints++;
                listOfPlayerFieldsOfCards[i].gameObject.GetComponent<Image>().color = colorForLose;
                listOfEnemyFieldsOfCards[i].gameObject.GetComponent<Image>().color = colorForVictory;
            }
            // when player and enemy have cards in this "i" section
            else
            {
                // Fight
                CardPanel playerCard;
                CardPanel enemyCard;
                // playerCard and enemyCard are scripts from our program take parameters
                playerCard = listOfPlayerFieldsOfCards[i].transform.GetChild(0).GetComponent<CardPanel>();
                enemyCard = listOfEnemyFieldsOfCards[i].transform.GetChild(0).GetComponent<CardPanel>();
                ParametsOfCard playerParamets = new ParametsOfCard(playerCard);
                ParametsOfCard enemyParamets = new ParametsOfCard(enemyCard);
                bool playerWin = false;
                // Line in below randomly let the winner in lottery first attack
                if ((UnityEngine.Random.Range(0, 2) == 1) && (LetTheDuelBegin(playerParamets, enemyParamets))) playerWin = true;
                else if (!LetTheDuelBegin(enemyParamets, playerParamets)) playerWin = true;
                if(playerWin)
                {
                    numberOfPlayerPoints++;
                    listOfPlayerFieldsOfCards[i].GetComponent<Image>().color = colorForVictory;
                    listOfEnemyFieldsOfCards[i].GetComponent<Image>().color = colorForLose;
                }
                else
                {
                    numberOfEnemyPoints++;
                    listOfPlayerFieldsOfCards[i].GetComponent<Image>().color = colorForLose;
                    listOfEnemyFieldsOfCards[i].GetComponent<Image>().color = colorForVictory;
                }
            }
        }
        if (numberOfPlayerPoints > numberOfEnemyPoints)
        {
            // If  player win then unblock next field/fields 
            field.tag = "Your Field";
            field.GetComponent<ChangerTagsScript>().ChangeTag();
        }
    }

    private bool LetTheDuelBegin(ParametsOfCard parametsOfCard1, ParametsOfCard parametsOfCard2)
    {
        // While one of player or enemy is't killed  then once again do 
        while (true)
        {
            // If this card in below have lucky then attack twice
            for(int numberOfAtacks = (UnityEngine.Random.Range(0, 101) < parametsOfCard1.chanceToDoubleAttack ? 2:1); numberOfAtacks > 0; numberOfAtacks--)
            {
                parametsOfCard2.health = parametsOfCard2.health - (parametsOfCard1.power - parametsOfCard2.armour) - parametsOfCard1.magicPower;
            }
            //return true when the winner(card1) in last lottery kill card2
            if (parametsOfCard2.health <= 0) return true;
            for (int numberOfAtacks = (UnityEngine.Random.Range(0, 101) < parametsOfCard2.chanceToDoubleAttack ? 2 : 1); numberOfAtacks > 0; numberOfAtacks--)
            {
                parametsOfCard1.health = parametsOfCard1.health - (parametsOfCard2.power - parametsOfCard1.armour) - parametsOfCard2.magicPower;
            }
            if (parametsOfCard1.health <= 0) return false;
        }
    }

    public void StartFight(GameObject field)
    {
        GetTheCards(field);
        OpenFightPanel();
        Fight(field.GetComponent<FieldScript>());
    }

}
