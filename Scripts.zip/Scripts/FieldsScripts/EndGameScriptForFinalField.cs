﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class EndGameScriptForFinalField : MonoBehaviour
{
    private void Update()
    {
        // If we win against the team in last Field then we win and go to next scene.
        // Name of the scene is "End"
        if (this.gameObject.tag == "Your Field")
        {
            LoadByName("End");
        }
    }
    public void LoadByName(string name)
    {
        SceneManager.LoadScene(name);
    }

}
