﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Events;
using UnityEngine.EventSystems;


public class BackgroundOfFieldScript : MonoBehaviour
{
    private SpriteRenderer sr;
    private Color normalBackgroundColorOfField;
    public bool ActivatedBackgroundOfField { get; set; }    // This variable is to show player what field is clicked
    public bool VisibleBackgroundOfField { get; set; }      // This variable is to show player what fields are blocked
    private Color colorIfNoVisible = Color.black;

    private void Awake()
    {
        sr = GetComponent<SpriteRenderer>();
        // this variable keep normal color what was set in unity
        normalBackgroundColorOfField = GetComponent<SpriteRenderer>().color;
        // In every field except Queluz set color to black, that mean this fields are not unblocked 
        if (this.transform.parent.name != "Queluz")
        {
            sr.color = colorIfNoVisible;
            ActivatedBackgroundOfField = false;
            VisibleBackgroundOfField = false;
        }
        else
        {
            // Set visible first field of the game, this field is starting field when player start
            ActivatedBackgroundOfField = true;
            VisibleBackgroundOfField = true;
        }
        this.gameObject.name = "Background Of " + transform.parent.name;
    }

    public void SetColor(bool active)
    {
        if (active)
            sr.color = normalBackgroundColorOfField;
        else
            sr.color = colorIfNoVisible;
    }

    private void OnMouseDown()
    {
        if(ActivatedBackgroundOfField)
            this.GetComponentInParent<TestModalPanel>().ModalWindowYNCI();
    }

    private void OnMouseOver()
    {
        if (VisibleBackgroundOfField)
        {
            sr.color = Color.yellow;
            ActivatedBackgroundOfField = true;
        }
    }
    private void OnMouseExit()
    {
        if (VisibleBackgroundOfField)
        {
            sr.color = normalBackgroundColorOfField;
            ActivatedBackgroundOfField = false;
        }
    }
}

