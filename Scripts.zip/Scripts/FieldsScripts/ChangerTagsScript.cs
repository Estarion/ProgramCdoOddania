﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// This class was created to unblock next field/fields
public class ChangerTagsScript : MonoBehaviour {

    private MenagerOfPlayer menagerOfPlayer;
    private List<GameObject> listOfFields;

    private void Awake()
    {
        menagerOfPlayer = MenagerOfPlayer.Instance();
        listOfFields = menagerOfPlayer.GetListOfFields();
    }

    // When program change tag in the Field then this method change parameters in field
    public void ChangeTag()
    {
        if (tag == "Your Field")
        {
            switch (name)
            {
                case "Queluz":
                    Changer(listOfFields[1]);
                    break;
                case "Coimbra":
                    Changer(listOfFields[2]);
                    break;
                case "Funchal":
                    Changer(listOfFields[3]);
                    Changer(listOfFields[4]);
                    break;
                case "Braga":
                    Changer(listOfFields[5]);
                    break;
                case "Amadora":
                    Changer(listOfFields[6]);
                    Changer(listOfFields[7]);
                    break;
                case "Vila Nova de Gaia":
                    Changer(listOfFields[8]);
                    break;
            }
        }
    }

    private void Changer(GameObject objectField)
    {
        objectField.GetComponent<FieldScript>().VisibleField = true;
        objectField.GetComponent<FieldScript>().SetColor(true);
        objectField.GetComponentInChildren<BackgroundOfFieldScript>().VisibleBackgroundOfField = true;
        objectField.GetComponentInChildren<BackgroundOfFieldScript>().SetColor(true);
    }
}
