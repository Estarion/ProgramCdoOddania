﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FieldScript : MonoBehaviour {

    public int AmountOfGoldProducedInOneTurn { get; set; }
    public int AmountOfDiamondsProducedInOneTurn { get; set; }
    private SpriteRenderer sr;
    private Color normalColorOfField;
    public bool VisibleField { get; set; }  
    private ModalPanel modalPanel;
    private Color colorIfNoVisible = Color.black;

    private void Awake()
    {
        sr = GetComponent<SpriteRenderer>();
        // this variable keep normal color what was set in unity
        normalColorOfField = sr.color;
        if (name != "Queluz")
        {
            sr.color = colorIfNoVisible;
            VisibleField = false;
        }
        // Set visible first field of the game, this field is starting field when player start
        else VisibleField = true;
        modalPanel = ModalPanel.Instance();
    }

    public void SetColor(bool  active)
    {
        if (active)
            sr.color = normalColorOfField;
        else
            sr.color = colorIfNoVisible;
    }
}