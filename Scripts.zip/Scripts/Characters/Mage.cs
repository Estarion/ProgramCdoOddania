﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using UnityEngine;

[System.Serializable]
public class Mage : Base
{
    public Mage(int levelOfTheUmpage = 0) : base()
    {
        Changer(2, 2 + levelOfTheUmpage, 0, 0 , 2, 1 + levelOfTheUmpage, 0, 0, 0, 0, levelOfTheUmpage);
        characterClass = "Mage";
    }

    public void ChangerParamets(int levelOfTheUmpage = 0)
    {
        Changer(2, 2 + levelOfTheUmpage, 0, 0, 2, 1 + levelOfTheUmpage, 0, 0, 0, 0, levelOfTheUmpage);
    }
}

