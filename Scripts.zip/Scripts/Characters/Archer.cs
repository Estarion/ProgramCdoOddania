﻿    using System;

[System.Serializable]
public class Archer : Base
{
    public Archer(int levelOfTheUmpage = 0) : base()
    {
        Changer(4, 2 + levelOfTheUmpage, 1, 1 + levelOfTheUmpage, 0, 0, 0, 0, 30, 20 + levelOfTheUmpage * 10, levelOfTheUmpage);
        characterClass = "Archer";
    }

    public void ChangerParamets(int levelOfTheUmpage = 0)
    {
        Changer(4, 2 + levelOfTheUmpage, 1, 1 + levelOfTheUmpage, 0, 0, 0, 0, 30, 20 + levelOfTheUmpage * 10, levelOfTheUmpage);
    }
}
