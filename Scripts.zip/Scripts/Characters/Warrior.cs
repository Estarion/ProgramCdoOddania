﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections;
using UnityEngine;

[System.Serializable]
public class Warrior : Base
{
    public Warrior(int levelOfTheUmpage = 0) : base()
    {
        Changer(5, 3 + levelOfTheUmpage*2, 1, 1 + (levelOfTheUmpage + 1) / 2, 0, 0 , 0, (int)(2+levelOfTheUmpage)/2, 0, 
            20 + levelOfTheUmpage*3, levelOfTheUmpage);
        characterClass = "Warrior";
    }

    public void ChangerParamets(int levelOfTheUmpage = 0)
    {
        Changer(5, 3 + levelOfTheUmpage * 2, 1, 1 + (levelOfTheUmpage + 1) / 2, 0, 0, 0, (int)(2 + levelOfTheUmpage) / 2, 0,
            20 + levelOfTheUmpage * 3, levelOfTheUmpage);
    }
}


