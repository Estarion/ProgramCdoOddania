﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Linq;
using System.Text;

[System.Serializable]
public abstract class Base {

    // Stats for Card
    protected int maxLifePoints = 0;
    protected int LifePoints { get; set; }
    protected string nameOfCharacter = "none";
    protected string introduce = "none"; 
    protected int rarity = 0;
    protected int age = 0;
    protected int power = 0;
    protected int magicPower = 0;
    protected int armour = 0;
    protected int chanceToCriticalAttack = 0;  
    protected int level = 1;
    protected string characterClass = "none";

    protected List<string> listOfIntroduce = new List<string>();
    protected List<string> listOfCharactersName = new List<string>();
    private System.Random random = new System.Random();

    protected Base()
    {
        AddingToLists();
        // Give to new object based on Base or any of character a random  name, introduce and age
        nameOfCharacter = listOfCharactersName[random.Next()%listOfCharactersName.Count];
        introduce = listOfIntroduce[random.Next()%listOfIntroduce.Count];
        age = random.Next()%70 +15;
    }

    protected void AddingToLists()
    {
        listOfIntroduce.Add("Będe walczyć do końca Panie. Jestem lojalnym najemnikiem.");
        listOfIntroduce.Add("Za dnia: Bóg, Honor, Ojczyzna lecz w czasie wojny palić, rabować, " +
            "mordować.Chyba w tej kolejności mamusia mnie uczyła.");
        listOfIntroduce.Add("Wybierz mnie a ofiaruje Ci swoje życie");
        listOfIntroduce.Add("Nie pożałujesz że mnie wybrałeś");
        listOfIntroduce.Add("Wybierz mnie albo wpierdol");
        listOfIntroduce.Add("Jeśli dobrze zapłacisz to zaoferuje Ci swe życie");
        listOfIntroduce.Add("Komu mam wybić oko ?");
        listOfIntroduce.Add("Zmiażdżyć czy zniszczyć oto jest pytanie");

        listOfCharactersName.Add("Conniss");
        listOfCharactersName.Add("Tarkor");
        listOfCharactersName.Add("Sevendo");
        listOfCharactersName.Add("Haemes");
        listOfCharactersName.Add("Hlakan");
        listOfCharactersName.Add("Neiusza");
        listOfCharactersName.Add("Jerhen");
        listOfCharactersName.Add("Teokran");
        listOfCharactersName.Add("Horlicht");
        listOfCharactersName.Add("Gerdak");
        listOfCharactersName.Add("Fredonas");
        listOfCharactersName.Add("Arkanin");
        listOfCharactersName.Add("Ravern");
        listOfCharactersName.Add("Lukard");
        listOfCharactersName.Add("Atrumph");
        listOfCharactersName.Add("Grundr");
        listOfCharactersName.Add("Whiter");
        listOfCharactersName.Add("Mogiazi");
        listOfCharactersName.Add("Jazowyja");
        listOfCharactersName.Add("Asartaxl");
        listOfCharactersName.Add("Ookian");
        listOfCharactersName.Add("Morwald");
    }

    public void Changer(int _maxLifePoints,  int _randomLifePoints,  int _power, int _randomPower,  
                           int _magicPower, int _randomMagicPower, int _armour, int _randomAromour, 
                           int _chanceToCriticalAttack, int _randomChanceToCriticalAttack, int _rarity)
    {
        //  This method change parameters in character by given variable 
        nameOfCharacter = listOfCharactersName[random.Next()%listOfCharactersName.Count];
        introduce = listOfIntroduce[random.Next()%listOfIntroduce.Count];
        age = random.Next() % 70 + 15;
        maxLifePoints = RandomIfNoZero(_randomLifePoints) + _maxLifePoints;
        LifePoints = maxLifePoints;
        power = RandomIfNoZero(_randomPower) + _power;
        magicPower = RandomIfNoZero(_randomMagicPower) + _magicPower;
        armour = RandomIfNoZero(_randomAromour) + _armour;
        chanceToCriticalAttack = RandomIfNoZero(_randomChanceToCriticalAttack) + _chanceToCriticalAttack;
        rarity = RandomIfNoZero(_rarity);
    }

    public void Setup(Text _name, Text _maxLifePoints, Text _power, Text _magicPower, Text _armour,
                       Text _chanceToCriticalAttack, Text _level, Text _rarity)
    {
        // give card stats
        _name.text = nameOfCharacter;
        _maxLifePoints.text = maxLifePoints.ToString();
        _power.text = power.ToString();
        _magicPower.text = magicPower.ToString();
        _armour.text = armour.ToString();
        _chanceToCriticalAttack.text = chanceToCriticalAttack.ToString();
        _level.text = level.ToString();
        _rarity.text = rarity.ToString();
    }

    private int RandomIfNoZero(int randomValue)
    {
        if (randomValue != 0) return (random.Next()%randomValue);
        else return 0;
    }
}

