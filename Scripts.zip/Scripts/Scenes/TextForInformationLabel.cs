﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TextForInformationLabel : MonoBehaviour {

    public Text text;

    private void Awake()
    {
        text.text = "Witam w mojej grze realizowanej w ramach Akademii C#." +
            "\n" +
            "Zasady gry:\n" +
            "Celem gry jest podbicie kontynentu zdobywając krok po kroku kolejne tereny strzeżone przez" +
            "drużyny jednostek. Aby pokonać wroga, gracz  musi stworzyć własną optymalną drużyne na daną walke.\n" +
            "Gracz ma możliwość rekrutacji i ulepszania jednostek za odpowiednią opłatą. Maksymalny level jaki może mieć karta jest piąty, " +
            "a po jego osiągnieciu karta dostaje swą podklase która zależy od obecnej tury. Czym dalsza tura tym silniejszą podklase " +
            "dostanie. Reprezentuje ona wiek w której karta została ulepszona. Jednak należy uważać ,gdyż dana klasa może tylko jeden raz " +
            "otrzymać podklase,  więc czasami cierpliwość popłaca. ;)\n " +
            "Aby rozpocząć walke o dane terytorium należy kliknąć w pole po czym zakceptować warunki. Walka trwa dwie tury jednak" +
            " otrzymujesz surowce za jedną. " +
            "Gracz wygra daną bitwe jeśli wygra wiecej pojedynków niż komputer ,które odbywają się pomiędzy kartami charakteryzujących " +
            "naszych bohaterów.\n" +
            "Każde Twoje pole generuje surowce z każdą kolejną turą, które możesz uzyć do ulepszenia.\n\n" +
            "\tŻyczę miłej gry.";
    }
}
