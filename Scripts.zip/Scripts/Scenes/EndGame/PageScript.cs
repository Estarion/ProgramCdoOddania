﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;
using System.Collections.Generic;
using UnityEngine.EventSystems;

public class PageScript : MonoBehaviour, IPointerClickHandler
{
    public GameObject nextPage;

    public void OnPointerClick(PointerEventData eventData)
    {
        nextPage.SetActive(true);
        this.gameObject.SetActive(false);
    }
}
