﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PageWithInformationAboutTurnScript : MonoBehaviour {

    public Text text;

    private void Awake()
    {
        text.text = "YOU WIN THIS GAME\n" +
            "IN " + PlayerSettings.GetTurn().ToString() + " TURNS";
    }
}
